Directory content details:

 * `libraries` contains Arduino 1.0 compatible, USB_HOST_SHIELD 1.x
   compatible Android accessories related libraries. This code is VERY
   reliable. Works 99% of the times. As long as your Android device
   supports Accessory mode, this should work without a problem

 * `libraries-v2` contains the USB_HOST_SHIELD 2.x library.
   This is our UNSTABLE branch, use at your own risk, we are still 
   cleaning up this code to behave properly

It is of course based in the original by CircuitsAtHome.com and has been patched by Follower (RancidBacon.com)