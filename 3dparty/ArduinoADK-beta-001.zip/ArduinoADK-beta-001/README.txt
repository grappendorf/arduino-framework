Android ADK for Arduino

The Processing directory contains a few things:

	* in the tools directory, there is the Processing "tool" for compiling against Android API revision 10.  The folder within the "tools" folder should be placed in the Processing sketch folder in a folder called "tools". Then restart Processing.  Then, to run the sketch on your phone, select "Arduino ADK" from the Tools menu in Processing. Make sure the model, manufacturer, and version match the variables with those names in your Arduino sketch. Then click "Run on Device". Processing will upload the sketch to your phone.

	* in the libraries directory, a Processing library, easing the communication between the ADK and Processing/Android.  The entire ArduinoAdkUsb folder should be copied into the user's Processing sketch folder in a folder called "libraries" -- MISSING THE ACTUAL LIBRARY AND DOCS

  * in the eclipse_lib_development directory, the original Eclipse project used to develop the above mentioned tool. Please note it migh be lacking some of the Processing Code libraries to be linked properly. Also you should read Processing guidelines on how to develop libraries if you want to make use of this source.

The Arduino directory contains two things:

	* Dave's modification of the AndroidAccessory library, which includes the capability for using all the Print and Stream functions.  Any transmission to the Android device needs to be packetized using beginTransmission() and endTransmission(), however.  There's one example included that will send two analog inputs and read a byte to set an analog output.  When we get the Android side working, this will be a good test sketch.

	* the USB Host Shield library v1 by CircuitsAtHome.com, patched by Follower (RancidBacon.com) to improve its reliability up to 99%.
	
Credits:

- Oleg aka Circuits@home for his original USB_Host library
- Follower for the fix that makes this library work reliably 99% of the times
- Andreas Goransson for the Android library to handle the communication from Processing
- David Cuartielles for packing a compiler for Processing that supports Accessory mode
- Brian Jepsson for the patch that magically updated the Processing tool to Processing 2.0
		
KNOWN ISSUE: the tool compiles great for Android 2.3.4 devices (or compatible with the com.future.usb library, but not with the latest usb api. In other words, this will crash with your super cute tablet running Android 4.0. This is just a matter of modifying the way the manifest file is generated, if you have the time to take a look at it and solve it ... just make a pull request and we will bring it in!

