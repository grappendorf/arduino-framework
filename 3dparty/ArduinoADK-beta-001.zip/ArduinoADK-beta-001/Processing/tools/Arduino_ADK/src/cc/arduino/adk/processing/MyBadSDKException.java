package cc.arduino.adk.processing;

@SuppressWarnings("serial")
public class MyBadSDKException extends Exception {
  public MyBadSDKException(final String message) {
    super(message);
  }
}
