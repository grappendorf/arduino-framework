package cc.arduino.adk.processing;

public interface MyDeviceProperties {
  public static final String APP_STARTED = "android.device.app.started";
  public static final String APP_ENDED = "android.device.app.ended";
}
